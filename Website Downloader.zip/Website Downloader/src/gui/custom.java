/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.Graphics;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author hp
 */
public class custom extends JLabel{
    
    @Override
    public void paint(Graphics g)
    {
    g.drawString("sdsf", 100, 100);
    }
    
}
