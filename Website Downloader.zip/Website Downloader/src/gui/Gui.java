/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import javax.swing.JFrame;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ----HP--2017-----
 */
public class Gui {

    /**
     * @param args the command line arguments
     */
//    public static void main(String[] args) {
//        // TODO code application logic here
//       /* SwingUtilities.invokeLater(new Runnable(){
//         public void run(){
//         new login();
//         }
//         });*/
//        login l = new login();
//        
//        l.setVisible(true);
//        
//        URL_u u = new URL_u();
//        
//        
//         System.out.print(URL_u.control.getPathStr() + 
//         URL_u.control.getUrlStr());
//        
//        WebCrawler web = new WebCrawler("https://www.w3schools.com");
//        
//        Storage st = new Storage();
//        
//        Images im = new Images();
//        
//        System.out.println("Enter the path");
//        
//        Scanner p = new Scanner(System.in);
//        
//        String path, url;
//        
//        path = p.nextLine();
//        
//        im.extract_imag(path, web);//بجبلي الصور
//
//        st.write_file(st.new_file(path), im, web);
//
//    }

}
