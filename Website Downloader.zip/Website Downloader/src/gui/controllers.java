/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;


public class controllers {
    
    private String url_str;
    private String path_str;
    
    // get Attr
    
    public String getUrlStr () { return url_str;}
    public String getPathStr () { return path_str;}
    
    // set Attr
    
    public void setUrlStr (String URL) { this.url_str = URL;}
    public void setPathStr (String Path) { this.path_str = Path;}
    
}
