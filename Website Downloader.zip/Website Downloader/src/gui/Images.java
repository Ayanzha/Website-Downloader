/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.io.BufferedOutputStream;//
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 *
 * @author ----HP--2017-----
 */
public class Images {

    public URL url;
    public ArrayList imges = new ArrayList();//source قبل التعديل
    public ArrayList set_img = new ArrayList();//sourبعدل التعديل 
    public Document document = new Document(null);

    public void doc(Document document) {
        this.document = document;
    }

    public void extract_imag(String Folderpath)//استخراج الصور 
    {
        try {

            Elements img = document.getElementsByTag("img");
            //  System.out.println(web.get_html());
            for (Element el : img) {//امشي عالمصفوفة
                String src = el.absUrl("src");//جبلي المسار
                imges.add(src);// حط المسار بالاري ليست

                getImages(src, Folderpath);//استدعاء لتابع عم يحملي الصورة
                setter_imag(src, Folderpath, el);//لتعديل source
            }
        } catch (IOException ex) {

      }

    }

    public void getImages(String src, String Folderpath) throws IOException {

        int indexname = src.lastIndexOf("/");

        if (indexname == src.length()) {
            src = src.substring(1, indexname);//جزئلي المسار
        }

        indexname = src.lastIndexOf("/");
        String name = src.substring(indexname +1 , src.length());

        System.out.print(name);
        URL url = new URL(src);
        InputStream in = url.openStream();

        OutputStream out = new BufferedOutputStream(new FileOutputStream(Folderpath + name));
        set_img.add(Folderpath + name);
        for (int b; (b = in.read()) != -1;) {
            out.write(b);
        }
        out.close();
        in.close();

    }

    public void setter_imag(String src, String path, Element img) {
        int indexname = src.lastIndexOf("/");

        if (indexname == src.length()) {
            src = src.substring(1, indexname);
        }

        indexname = src.lastIndexOf("/");
        String name = src.substring(indexname, src.length());

        img.outerHtml();
        img.attr("src", path + "\\" + name);
        img.outerHtml();

    }

    public Document Set_html() {

        return document;

    }

}
